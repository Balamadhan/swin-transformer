#!/bin/bash
# Assignment 1

# Set database credentials
DB_NAME="postgres"
DB_USER="postgres"
DB_PASSWORD="postgres"
DB_HOST="127.0.0.1"
DB_PORT="5432"

# Environment variables to psql
export PGPASSWORD=$DB_PASSWORD
# Connect to PostgreSQL and set encoding
echo "Setting client encoding to UTF-8"
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "SET CLIENT_ENCODING TO 'utf8';"

# Step 1: Creating tables
echo "Creating tables..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f create_tables.sql
echo "creating relations.."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f create_relations.sql

# Step 3: Import data from CSV
echo "Importing data into the database..."

# Importing  authors.csv
echo "Importing authors.csv..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "\copy authors (id, retrieved_on, name, created_utc, link_karma, comment_karma, profile_img, profile_color, profile_over_18) FROM 'authors.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';

# Importing submissions.csv
echo "Importing submissions.csv..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "\copy submissions (downs, url, id, edited, num_reports, created_utc, name, title, author, permalink, num_comments, likes, subreddit_id, ups) FROM 'submissions.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';"

# Importing subreddits.csv
echo "Importing subreddits.csv..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "\copy subreddits (banner_background_image, created_utc, description, display_name, header_img, hide_ads, id, over18, public_description, retrieved_utc, name, subreddit_type, subscribers, title, whitelist_status) FROM 'subreddits.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';"


# Importing submissions.csv
echo "Importing submissions.csv..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "\copy submissions (downs, url, id, edited, num_reports, created_utc, name, title, author, permalink, num_comments, likes, subreddit_id, ups) FROM 'submissions.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';"

# Importing comments.csv
echo "Importing comments.csv..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -c "\copy comments (distinguished, downs, created_utc, controversiality, edited, gilded, author_flair_css_class, id, author, retrieved_on, score_hidden, subreddit_id, score, name, author_flair_text, link_id, archived, ups, parent_id, subreddit, body) FROM 'comments.csv' DELIMITER ',' CSV HEADER ENCODING 'UTF8';"


# Step 4: Running queries
echo "Running SQL queries..."
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME -f queries.sql