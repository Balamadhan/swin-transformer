ALTER TABLE comments
ADD CONSTRAINT fk_comments_subreddit
FOREIGN KEY (subreddit) REFERENCES subreddits(display_name);

ALTER TABLE subreddits
ADD CONSTRAINT unique_name_1 UNIQUE (name);

ALTER TABLE comments
ADD CONSTRAINT fk_comments_subreddit_id
FOREIGN KEY (subreddit_id) REFERENCES subreddits(name);

ALTER TABLE authors
ADD CONSTRAINT unique_name_2 UNIQUE (name);

ALTER TABLE submissions
ADD CONSTRAINT fk_author
FOREIGN KEY (author) REFERENCES authors(name);

ALTER TABLE subreddits
ADD CONSTRAINT unique_name_2 UNIQUE (name);

ALTER TABLE submissions
ADD CONSTRAINT fk_subreddit_id
FOREIGN KEY (subreddit_id) REFERENCES subreddits(name);

ALTER TABLE comments
ADD CONSTRAINT fk_comments_author
FOREIGN KEY (author) REFERENCES authors(name);

ALTER TABLE subreddits
ADD CONSTRAINT unique_display_name UNIQUE (display_name);